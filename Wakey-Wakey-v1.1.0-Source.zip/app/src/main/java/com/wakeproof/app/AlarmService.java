package com.wakeproof.app;

import android.app.*;
import android.content.*;
import android.os.*;

public class AlarmService extends Service {
    static final String START="com.wakeproof.app.START",TEST="com.wakeproof.app.TEST",DEFUSE="com.wakeproof.app.DEFUSE",SELFIE_OK="com.wakeproof.app.SELFIE_OK",REFRESH_WALK="com.wakeproof.app.REFRESH_WALK";
    static final String CHANNEL="wakeproof.alarm.channel";
    private final Handler timer=new Handler(Looper.getMainLooper());
    private AudioEngine engine;
    private WalkTracker walkTracker;
    private android.os.Vibrator vibrator;
    private AlarmConfig alarm;
    private boolean ending=false;
    private long endAt;
    private int previousSecond=-1;
    private Runnable tickLoop;
    @Override public IBinder onBind(Intent i){return null;}
    static boolean active(Context c){return AlarmStore.prefs(c).getString("running",null)!=null;}
    static String currentId(Context c){return AlarmStore.prefs(c).getString("running",null);}
    static long endTime(Context c){return AlarmStore.prefs(c).getLong("endAt",0L);}
    static int confirmedSteps(Context c){return AlarmStore.prefs(c).getInt("walkSteps",0);}
    static boolean eyesDone(Context c){return AlarmStore.prefs(c).getBoolean("selfieVerified",false);}
    static double confirmedMeters(Context c,AlarmConfig a){return confirmedSteps(c)*a.strideCm/100.0;}
    static boolean walkingDone(Context c,AlarmConfig a){return confirmedMeters(c,a)+1e-5>=a.walkMeters;}
    static String walkReason(Context c){return AlarmStore.prefs(c).getString("walkReason","Ready to walk");}
    @Override public void onCreate(){super.onCreate();engine=new AudioEngine(this);vibrator=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);NotificationManager nm=getSystemService(NotificationManager.class);
        NotificationChannel ch=new NotificationChannel(CHANNEL,"Active alarms",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Urgent wake-up alarm. Open to complete walking and selfie challenges.");ch.setSound(null,null);ch.enableVibration(false);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);nm.createNotificationChannel(ch);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){String action=intent==null?"":intent.getAction();
        if(DEFUSE.equals(action)){tryDefuse();return START_STICKY;}
        if(SELFIE_OK.equals(action)){
            if(alarm!=null){AlarmStore.prefs(this).edit().putBoolean("selfieVerified",true).apply();tryDefuse();}
            return START_STICKY;
        }
        if(REFRESH_WALK.equals(action)){if(alarm!=null&&walkTracker==null)startWalking();return START_STICKY;}
        if(alarm!=null)return START_STICKY;
        String id=intent!=null?intent.getStringExtra("id"):null;
        if(id==null)id=currentId(this);
        alarm=id==null?null:AlarmStore.find(this,id);
        if(alarm==null){stopSelf();return START_NOT_STICKY;}
        long persistedEnd=endTime(this);
        if(id.equals(currentId(this))&&persistedEnd>0){endAt=persistedEnd;}
        else{endAt=System.currentTimeMillis()+alarm.seconds*1000L;
            AlarmStore.prefs(this).edit().putString("running",id).putLong("endAt",endAt)
                .putInt("walkSteps",0).putString("walkReason","Ready to walk").putBoolean("selfieVerified",false).apply();}
        ending=System.currentTimeMillis()>=endAt;
        if(Build.VERSION.SDK_INT>=29)startForeground(312,notification(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(312,notification());
        if(alarm.vibrate && vibrator!=null && vibrator.hasVibrator())vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0,140,860},0));
        if(ending)engine.finalLoop(alarm);else engine.playStart(alarm);
        startWalking();
        tickLoop=new Runnable(){@Override public void run(){if(alarm==null)return;
            long remaining=Math.max(0,(endAt-System.currentTimeMillis()+999)/1000);
            if(remaining==0&&!ending){ending=true;engine.finalLoop(alarm);getSystemService(NotificationManager.class).notify(312,notification());}
            if(!ending&&remaining!=previousSecond){previousSecond=(int)remaining;engine.tick(alarm);}
            timer.postDelayed(this,200);
        }};timer.postDelayed(tickLoop,800);
        return START_STICKY;
    }
    private void startWalking(){
        if(alarm==null||walkTracker!=null)return;
        WalkTracker candidate=new WalkTracker(this,alarm,()->{
            if(walkTracker==null)return;
            AlarmStore.prefs(this).edit().putInt("walkSteps",walkTracker.steps())
                .putString("walkReason",walkTracker.reason()).apply();
            if(walkTracker.complete()&&eyesDone(this))tryDefuse();
        });
        candidate.seed(confirmedSteps(this));
        if(candidate.start())walkTracker=candidate;
    }
    private void tryDefuse(){
        if(alarm!=null&&eyesDone(this)&&walkingDone(this,alarm))defuse();
    }
    private Notification notification(){Intent fullscreen=new Intent(this,RingActivity.class);fullscreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open=PendingIntent.getActivity(this,23,fullscreen,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_alarm).setContentTitle(ending?"Wakey Wakey · Time's up":"Wakey Wakey · Alarm active")
                .setContentText(ending?"Walk your distance and verify open eyes to stop.":"Countdown running · Walk + selfie to defuse")
                .setVisibility(Notification.VISIBILITY_PUBLIC).setCategory(Notification.CATEGORY_ALARM).setOngoing(true)
                .setAutoCancel(false).setFullScreenIntent(open,true).setContentIntent(open).build();
    }
    private void defuse(){AlarmStore.prefs(this).edit().remove("running").remove("endAt")
        .remove("selfieVerified").remove("walkSteps").remove("walkReason").apply();
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
    @Override public void onDestroy(){if(walkTracker!=null){walkTracker.stop();walkTracker=null;}if(vibrator!=null)vibrator.cancel();if(tickLoop!=null)timer.removeCallbacks(tickLoop);engine.stop();super.onDestroy();}
}
