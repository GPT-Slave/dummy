package com.wakeproof.app;

/** Plain JDK test, no Android runtime required. */
public final class WalkSignalFilterTest {
    private static void verify(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        WalkSignalFilter normal=new WalkSignalFilter(5,true,()->{});
        for(long ms=1000;ms<12000;ms+=20){
            double t=(ms-1000)/1000.0;
            normal.sample(ms,0,0,(float)(9.81+1.25*Math.sin(2*Math.PI*1.5*t)),.15f,.14f,.16f);
            if(ms%700==0)normal.hardwareStep(ms);
        }
        verify(normal.steps()>=9,"normal walking should accumulate, got "+normal.steps()+"; last="+normal.reason);
        WalkSignalFilter shake=new WalkSignalFilter(5,true,()->{});
        for(long ms=1000;ms<12000;ms+=20){
            double t=(ms-1000)/1000.0;
            shake.sample(ms,0,0,(float)(9.81+12.0*Math.sin(2*Math.PI*4.0*t)),5f,2f,1f);
            if(ms%500==0)shake.hardwareStep(ms);
        }
        verify(shake.steps()==0,"shaking must not accumulate; got "+shake.steps());
        verify(shake.rejected>0,"shake should reject hardware step events");
        WalkSignalFilter tooFast=new WalkSignalFilter(5,true,()->{});
        for(long ms=1000;ms<6000;ms+=20){tooFast.sample(ms,0,0,(float)(9.81+Math.sin(ms/140.0)),0,0,0);if(ms%200==0)tooFast.hardwareStep(ms);}
        verify(tooFast.rejected>0,"fast pulses should be rejected");
        System.out.println("PASS normal walking="+normal.steps()+", shaking="+shake.steps()+", shaking rejected="+shake.rejected+", rapid rejected="+tooFast.rejected);
    }
}
