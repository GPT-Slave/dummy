# Wakey Wakey · walk + selfie alarm

Native Android alarm clock. At alarm time, it plays a chosen start signal, configurable countdown tick and a looping final siren. To defuse, **both** challenges must finish: walk the configured estimated distance and take a fresh front-camera selfie with both eyes confidently open.

## What is configurable

- Multiple alarms, day-of-week repeats, name, exact time, duration, vibration.
- Separate sounds and volumes for alarm start, ticking and continuous final siren.
- Eye-open confidence (55–95%).
- Walking target (1–30 m in the calibration screen; existing saved values remain compatible), estimated stride length (35–100 cm), and motion-shake tolerance (1 strict … 10 permissive).
- Interactive **Sensor Lab** for 15-second walking tests, 10-second shaking tests, live accepted and rejected steps, accelerometer activity, gyroscope rotation, and on-device calibration.

## Walking detection technical details

The app uses Android's `TYPE_STEP_DETECTOR` when available plus raw accelerometer and gyroscope motion validation. On phones without a dedicated step detector, it uses a conservative accelerometer peak estimator. It requires three plausible walking steps in sequence to confirm activity and rejects fast/spinning/jarring patterns. Walk distance is **estimated** as accepted steps multiplied by configured stride length.

**Important:** accelerometers cannot prove translation through space. While this algorithm rejects obvious shaking, deliberate movements that mimic human gait can cause false steps, and very vigorous real walking can be rejected. It does not provide fraud-proof or meter-accurate motion tracking, nor does it use or require GPS. Calibrate on your own hardware and avoid setting an unreachable distance.

## Android permissions

- Camera: only while the front-camera challenge is visible. Images stay in memory and run through ML Kit face classification locally; no upload or saved selfie.
- Physical activity: Android 10+ permission for the hardware step detector. The app offers a fallback estimator if the sensor does not exist.
- Notifications, exact alarms and full-screen alarms: for reliable alarm notifications.

## Building

Open in Android Studio; Java 17, Gradle 8.9, Android SDK 35. Run `gradle --no-daemon :app:assembleDebug`. Install `app/build/outputs/apk/debug/app-debug.apk`.

## Testing

First, use the Sensor Lab, test 5–10 steps of normal walking, then shake the phone in place. Adjust tolerance and stride until accepted distance behaves reasonably. Next use **TRY NOW** on an alarm and verify both sequences (walking first or selfie first), especially after the timer expires. Test locked screen, volume, permissions, Android battery restrictions, recurring alarms, imported audio and reboot rescheduling on your device. An app cannot override OS force-stop, muted system volume, shutdown or device manufacturer alarm restrictions.
