package com.wakeproof.app;

import android.app.*;
import android.content.*;
import android.os.*;

public class AlarmService extends Service {
    static final String START="com.wakeproof.app.START",TEST="com.wakeproof.app.TEST",DEFUSE="com.wakeproof.app.DEFUSE";
    static final String CHANNEL="wakeproof.alarm.channel";
    private final Handler timer=new Handler(Looper.getMainLooper());
    private AudioEngine engine;
    private AlarmConfig alarm;
    private boolean ending=false;
    private long endAt;
    private int previousSecond=-1;
    private Runnable tickLoop;
    @Override public IBinder onBind(Intent i){return null;}
    static boolean active(Context c){return AlarmStore.prefs(c).getString("running",null)!=null;}
    static String currentId(Context c){return AlarmStore.prefs(c).getString("running",null);}
    static long endTime(Context c){return AlarmStore.prefs(c).getLong("endAt",0L);}
    @Override public void onCreate(){super.onCreate();engine=new AudioEngine(this);NotificationManager nm=getSystemService(NotificationManager.class);
        NotificationChannel ch=new NotificationChannel(CHANNEL,"Active alarms",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Urgent wake-up alarm. Open to verify a selfie.");ch.setSound(null,null);ch.enableVibration(false);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);nm.createNotificationChannel(ch);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){String action=intent==null?"":intent.getAction();
        if(DEFUSE.equals(action)){defuse();return START_NOT_STICKY;}
        if(alarm!=null)return START_STICKY;
        String id=intent!=null?intent.getStringExtra("id"):null;
        if(id==null)id=currentId(this);
        alarm=id==null?null:AlarmStore.find(this,id);
        if(alarm==null){stopSelf();return START_NOT_STICKY;}
        long persistedEnd=endTime(this);
        if(id.equals(currentId(this))&&persistedEnd>0){endAt=persistedEnd;}
        else{endAt=System.currentTimeMillis()+alarm.seconds*1000L;AlarmStore.prefs(this).edit().putString("running",id).putLong("endAt",endAt).apply();}
        ending=System.currentTimeMillis()>=endAt;
        startForeground(312,notification(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        if(ending)engine.finalLoop(alarm);else engine.playStart(alarm);
        tickLoop=new Runnable(){@Override public void run(){if(alarm==null)return;
            long remaining=Math.max(0,(endAt-System.currentTimeMillis()+999)/1000);
            if(remaining==0&&!ending){ending=true;engine.finalLoop(alarm);getSystemService(NotificationManager.class).notify(312,notification());}
            if(!ending&&remaining!=previousSecond){previousSecond=(int)remaining;engine.tick(alarm);}
            timer.postDelayed(this,200);
        }};timer.postDelayed(tickLoop,800);
        return START_STICKY;
    }
    private Notification notification(){Intent fullscreen=new Intent(this,RingActivity.class);fullscreen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open=PendingIntent.getActivity(this,23,fullscreen,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_alarm).setContentTitle(ending?"WakeProof · Time's up":"WakeProof · Alarm active")
                .setContentText(ending?"Take your open-eye selfie to stop the sound.":"Countdown is running · Verify to defuse")
                .setVisibility(Notification.VISIBILITY_PUBLIC).setCategory(Notification.CATEGORY_ALARM).setOngoing(true)
                .setAutoCancel(false).setFullScreenIntent(open,true).setContentIntent(open).build();
    }
    private void defuse(){AlarmStore.prefs(this).edit().remove("running").remove("endAt").apply();stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
    @Override public void onDestroy(){if(tickLoop!=null)timer.removeCallbacks(tickLoop);engine.stop();super.onDestroy();}
}
