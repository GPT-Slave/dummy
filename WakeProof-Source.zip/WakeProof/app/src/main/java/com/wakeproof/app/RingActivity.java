package com.wakeproof.app;

import android.Manifest;
import android.animation.ValueAnimator;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.*;
import java.util.List;

public class RingActivity extends ComponentActivity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private AlarmConfig alarm;
    private long endAt;
    private boolean verified=false,checking=false;
    private TextView title,status,primary,shoot,smallTimer;
    private LinearLayout page,selfieZone;
    private CountdownView ring;
    private PreviewView previewView;
    private ImageCapture imageCapture;
    private ProcessCameraProvider cameraProvider;
    private boolean cameraVisible=false;
    private final Runnable refresh=new Runnable(){@Override public void run(){updateTimer();handler.postDelayed(this,150);}};
    @Override public void onCreate(Bundle state){super.onCreate(state);
        setShowWhenLocked(true);setTurnScreenOn(true);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        String id=AlarmService.currentId(this);alarm=id==null?null:AlarmStore.find(this,id);endAt=AlarmService.endTime(this);
        if(alarm==null){finish();return;}setVolumeControlStream(android.media.AudioManager.STREAM_ALARM);render();handler.post(refresh);
    }
    private void render(){page=Ui.screen(this);Ui.add(page,Ui.label(this,"W / P     LIVE ALARM"));Ui.space(page,this,19);
        title=Ui.text(this,"You can do this.",34,Ui.WHITE,true);Ui.add(page,title);Ui.space(page,this,10);
        status=Ui.text(this,"The countdown is running. Your eyes are the key.",15,Ui.MUTED,false);Ui.add(page,status);Ui.space(page,this,23);
        ring=new CountdownView(this);Ui.add(page,ring);Ui.space(page,this,17);
        smallTimer=Ui.text(this,"",14,Ui.LIME,true);smallTimer.setGravity(Gravity.CENTER);Ui.add(page,smallTimer);Ui.space(page,this,21);
        primary=Ui.button(this,"◉    OPEN THE SELFIE CAMERA",true);primary.setOnClickListener(v->openCamera());Ui.add(page,primary);
        Ui.space(page,this,18);Ui.add(page,Ui.text(this,"Face the front camera with both eyes clearly open. No snooze, no accidental dismissal.",13,Ui.MUTED,false));
        selfieZone=Ui.column(this);selfieZone.setVisibility(View.GONE);Ui.space(selfieZone,this,17);
        LinearLayout container=Ui.card(this);Ui.add(container,Ui.label(this,"EYES OPEN  /  LOOK STRAIGHT"));Ui.space(container,this,14);
        previewView=new PreviewView(this);previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,Ui.dp(this,300));container.addView(previewView,p);
        Ui.space(container,this,15);shoot=Ui.button(this,"●    CAPTURE SELFIE",true);shoot.setOnClickListener(v->takeSelfie());Ui.add(container,shoot);
        Ui.space(container,this,11);Ui.add(container,Ui.text(this,"Your photo is analyzed in memory, not saved or uploaded.",12,Ui.MUTED,false));Ui.add(selfieZone,container);Ui.add(page,selfieZone);
    }
    private void updateTimer(){if(verified)return;if(!AlarmService.active(this)){finish();return;}
        long ms=Math.max(0,endAt-System.currentTimeMillis());int sec=(int)((ms+999)/1000);ring.update(sec,Math.max(1,alarm.seconds));
        if(ms>0){title.setText("You can do this.");status.setText("Take the selfie now, or the siren will keep playing.");smallTimer.setText("COUNTDOWN RUNNING   /   "+sec+"s LEFT");}
        else{title.setText("Time's up.");status.setText("The final sound will repeat until you prove you're awake.");smallTimer.setText("SIREN ACTIVE   /   SELFIE REQUIRED");}
    }
    private void openCamera(){if(cameraVisible)return;
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},81);return;}
        showCamera();
    }
    private void showCamera(){cameraVisible=true;ring.setVisibility(View.GONE);primary.setVisibility(View.GONE);selfieZone.setVisibility(View.VISIBLE);
        if(cameraProvider!=null){bindCamera();return;}
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);
        future.addListener(()->{try{cameraProvider=future.get();if(!isFinishing())bindCamera();}catch(Exception e){Ui.toast(this,"Unable to open the front camera: "+e.getMessage());}},ContextCompat.getMainExecutor(this));
    }
    private void bindCamera(){try{
        cameraProvider.unbindAll();Preview preview=new Preview.Builder().build();preview.setSurfaceProvider(previewView.getSurfaceProvider());
        imageCapture=new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build();
        cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,preview,imageCapture);
    }catch(Exception e){shoot.setText("FRONT CAMERA UNAVAILABLE");shoot.setEnabled(false);Ui.toast(this,"Front camera unavailable");}}
    private void takeSelfie(){if(checking||imageCapture==null)return;checking=true;shoot.setText("VERIFYING EYES…");shoot.setEnabled(false);
        imageCapture.takePicture(ContextCompat.getMainExecutor(this),new ImageCapture.OnImageCapturedCallback(){
            @Override public void onCaptureSuccess(ImageProxy frame){android.media.Image media=frame.getImage();if(media==null){frame.close();reject("Camera returned an empty image. Try again.");return;}
                InputImage img=InputImage.fromMediaImage(media,frame.getImageInfo().getRotationDegrees());
                FaceDetectorOptions opts=new FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                        .setMinFaceSize(.16f).build();FaceDetector detector=FaceDetection.getClient(opts);
                detector.process(img).addOnSuccessListener(faces->{if(isFinishing()){return;}evaluate(faces);})
                        .addOnFailureListener(e->reject("Couldn't analyze that photo. Try again."))
                        .addOnCompleteListener(t->{frame.close();detector.close();});
            }
            @Override public void onError(ImageCaptureException e){reject("Camera capture failed. Try again.");}
        });
    }
    private void evaluate(List<Face> faces){if(faces.size()!=1){reject(faces.isEmpty()?"No face found. Move into the frame.":"Only one face should be in the frame.");return;}
        Face face=faces.get(0);Float left=face.getLeftEyeOpenProbability(),right=face.getRightEyeOpenProbability();
        if(left==null||right==null){reject("Make sure both eyes are clearly visible.");return;}
        if(Math.abs(face.getHeadEulerAngleY())>21||Math.abs(face.getHeadEulerAngleZ())>22){reject("Look straight at the camera.");return;}
        float threshold=alarm.eyeThreshold/100f;
        if(left<threshold||right<threshold){reject("Open both eyes wider. Left "+Math.round(left*100)+"% · Right "+Math.round(right*100)+"%.");return;}
        verified=true;checking=false;getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        startService(new Intent(this,AlarmService.class).setAction(AlarmService.DEFUSE));
        if(cameraProvider!=null)cameraProvider.unbindAll();
        page.removeAllViews();Ui.space(page,this,80);
        TextView icon=Ui.text(this,"✓",90,Ui.LIME,true);icon.setGravity(Gravity.CENTER);Ui.add(page,icon);Ui.space(page,this,20);
        TextView success=Ui.text(this,"Defused.",42,Ui.WHITE,true);success.setGravity(Gravity.CENTER);Ui.add(page,success);Ui.space(page,this,10);
        TextView note=Ui.text(this,"Eyes open. You're officially awake.",17,Ui.MUTED,false);note.setGravity(Gravity.CENTER);Ui.add(page,note);Ui.space(page,this,33);
        TextView done=Ui.button(this,"BACK TO ALARMS",true);done.setOnClickListener(v->{startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));finish();});Ui.add(page,done);
    }
    private void reject(String reason){checking=false;shoot.setEnabled(true);shoot.setText("●    TRY ANOTHER SELFIE");status.setText(reason);status.setTextColor(Ui.RED);}
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] grants){super.onRequestPermissionsResult(code,perms,grants);
        if(code==81&&grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)showCamera();else if(code==81)Ui.toast(this,"Camera permission is needed to defuse the alarm.");}
    @Override protected void onDestroy(){handler.removeCallbacks(refresh);if(cameraProvider!=null)cameraProvider.unbindAll();super.onDestroy();}
    @Override public void onBackPressed(){if(cameraVisible){if(cameraProvider!=null)cameraProvider.unbindAll();cameraVisible=false;ring.setVisibility(View.VISIBLE);primary.setVisibility(View.VISIBLE);selfieZone.setVisibility(View.GONE);}
        else super.onBackPressed();}
    static final class CountdownView extends View {
        private final Paint paint=new Paint(3);private int sec=1,total=30;
        CountdownView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void update(int s,int t){if(sec!=s||total!=t){sec=s;total=t;invalidate();}}
        @Override protected void onMeasure(int w,int h){int size=Math.min(MeasureSpec.getSize(w),Ui.dp(getContext(),300));setMeasuredDimension(size,size);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float x=getWidth()/2f,y=getHeight()/2f,r=getWidth()*.43f;paint.setStrokeWidth(Ui.dp(getContext(),8));paint.setStyle(Paint.Style.STROKE);paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(Ui.STROKE);c.drawCircle(x,y,r,paint);
            paint.setColor(sec==0?Ui.RED:Ui.LIME);c.drawArc(x-r,y-r,x+r,y+r,-90,360f*(sec/(float)Math.max(1,total)),false,paint);
            paint.setStyle(Paint.Style.FILL);paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
            paint.setTextSize(Ui.dp(getContext(),sec==0?44:75));paint.setColor(sec==0?Ui.RED:Ui.WHITE);
            String number=sec==0?"00":String.format(java.util.Locale.getDefault(),"%02d",sec);c.drawText(number,x,y+Ui.dp(getContext(),15),paint);
            paint.setTextSize(Ui.dp(getContext(),12));paint.setTypeface(Typeface.create("sans-serif-medium",0));paint.setColor(Ui.MUTED);
            c.drawText(sec==0?"TIME EXPIRED":"SECONDS LEFT",x,y+Ui.dp(getContext(),47),paint);
        }
    }
}
