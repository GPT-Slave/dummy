package com.wakeproof.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.*;
import android.os.Build;
import android.provider.Settings;
import java.util.*;

final class AlarmScheduler {
    static PendingIntent pending(Context c,AlarmConfig a){Intent i=new Intent(c,AlarmReceiver.class).setAction("com.wakeproof.app.ALARM").putExtra("id",a.id);i.setData(android.net.Uri.parse("wakeproof://alarm/"+a.id));return PendingIntent.getBroadcast(c,a.id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static boolean allowed(Context c){AlarmManager m=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);return Build.VERSION.SDK_INT<31||m.canScheduleExactAlarms();}
    static void permission(Context c){if(Build.VERSION.SDK_INT>=31){try{Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:"+c.getPackageName()));if(!(c instanceof android.app.Activity))i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);}catch(Exception e){Ui.toast(c,"Enable Alarms & reminders in Android settings");}}}
    static long next(AlarmConfig a){Calendar now=Calendar.getInstance();Calendar cal=Calendar.getInstance();cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);cal.set(Calendar.HOUR_OF_DAY,a.hour);cal.set(Calendar.MINUTE,a.minute);if(a.days==0){if(cal.getTimeInMillis()<=now.getTimeInMillis())cal.add(Calendar.DAY_OF_YEAR,1);return cal.getTimeInMillis();}for(int i=0;i<8;i++){int index=(cal.get(Calendar.DAY_OF_WEEK)+5)%7; // Monday=0, Sunday=6
        if(cal.getTimeInMillis()>now.getTimeInMillis()&&(a.days&(1<<index))!=0)return cal.getTimeInMillis();cal.add(Calendar.DAY_OF_YEAR,1);
    }return -1;}
    static void schedule(Context c,AlarmConfig a){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);am.cancel(pending(c,a));if(!a.enabled||!allowed(c))return;long t=next(a);if(t<=0)return;Intent view=new Intent(c,MainActivity.class);PendingIntent show=PendingIntent.getActivity(c,a.id.hashCode(),view,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);try{am.setAlarmClock(new AlarmManager.AlarmClockInfo(t,show),pending(c,a));}catch(SecurityException e){Ui.toast(c,"Allow exact alarms to schedule your wake-up");}}
    static void rescheduleAll(Context c){for(AlarmConfig a:AlarmStore.all(c))schedule(c,a);}
}
