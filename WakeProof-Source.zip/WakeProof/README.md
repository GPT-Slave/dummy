# WakeProof · open-eye alarm

An Android alarm clock that plays a configurable start signal, a second-by-second countdown tick, and a looping final siren until a selfie passes ML Kit on-device open-eye verification.

## Features
- Multiple exact time-of-day alarms, one-off or weekday/day-of-week recurring schedules.
- Independent built-in or imported audio and volume settings for start, tick, and final phases.
- Configurable countdown (5–180 seconds) and eye confidence (55–95%).
- Face/eyes analyzed in memory with Google's bundled ML Kit face model; selfies are not stored or uploaded.
- Foreground media playback service, high-importance full-screen alarm notification, reboot/time-change rescheduling.
- A native front-camera selfie challenge powered by CameraX.

## Building
Android Studio / Gradle with Java 17, Android SDK 35, Gradle 8.9; run `gradle :app:assembleDebug`. APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Setup
Install APK, allow notifications, exact alarm permissions if prompted, full-screen alarms if required by Android, and camera access when checking your face. Android alarm stream/system settings affect actual loudness. Some vendors restrict app background execution; exclude WakeProof from aggressive battery optimization if your device delays alarms.

## Notes and limitations
- Eye-open detection is not identity recognition: a single face with both eyes open will pass; it doesn't establish the face is specifically the owner's.
- An app cannot guarantee endless audio after an Android force-stop, device shutdown, device mute, or restrictive OEM behavior.
- False negatives are possible; the alarm continues playing while you retry. Android system settings remain an emergency force-stop avenue.
- No server or login. Camera frames are processed in memory.
