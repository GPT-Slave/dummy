package com.wakeproof.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.*;
import android.os.Build;
import android.os.SystemClock;
import java.util.Locale;

/** Shared by the running alarm service and the stand-alone calibration screen. */
final class WalkTracker implements SensorEventListener {
    interface Update { void onWalkUpdate(); }
    private final Context context;
    private final AlarmConfig config;
    private final SensorManager sensors;
    private final Sensor accelerometer,gyro,hardwareStep;
    private final WalkSignalFilter filter;
    private final Update callback;
    private final float[] rotations=new float[3];
    private boolean started;
    private int seedSteps;
    WalkTracker(Context c,AlarmConfig a, Update listener){
        context=c;config=a;callback=listener;
        sensors=(SensorManager)c.getSystemService(Context.SENSOR_SERVICE);
        accelerometer=sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyro=sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        hardwareStep=sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        filter=new WalkSignalFilter(a.shakeTolerance,hardwareStep!=null,()->{if(callback!=null)callback.onWalkUpdate();});
    }
    static boolean hasPermission(Context c){return Build.VERSION.SDK_INT<29||c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)==PackageManager.PERMISSION_GRANTED;}
    boolean canTrack(){return accelerometer!=null&&(hardwareStep==null||hasPermission(context));}
    boolean usingHardware(){return hardwareStep!=null;}
    boolean start(){
        if(started)return true;
        if(!canTrack())return false;
        if(accelerometer==null)return false;
        boolean ok=sensors.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_GAME);
        if(!ok)return false;
        if(gyro!=null)sensors.registerListener(this,gyro,SensorManager.SENSOR_DELAY_GAME);
        if(hardwareStep!=null)sensors.registerListener(this,hardwareStep,SensorManager.SENSOR_DELAY_NORMAL);
        started=true;return true;
    }
    void stop(){if(started)sensors.unregisterListener(this);started=false;}
    boolean isRunning(){return started;}
    void seed(int stepCount){seedSteps=Math.max(0,stepCount);}
    int steps(){return seedSteps+filter.steps();}
    int rejected(){return filter.rejected;}
    int candidates(){return filter.candidates;}
    int shakes(){return filter.shakeEvents;}
    double meters(){return steps()*config.strideCm/100.0;}
    boolean complete(){return meters()+1e-5>=config.walkMeters;}
    String reason(){return filter.reason;}
    String sensorMode(){return hardwareStep!=null?"Android step sensor + motion validation":"Accelerometer step estimator";}
    float impact(){return filter.acceleration;}
    float rotation(){return filter.spin;}
    @Override public void onSensorChanged(SensorEvent e){
        long t=e.timestamp/1_000_000L;
        if(e.sensor.getType()==Sensor.TYPE_GYROSCOPE){System.arraycopy(e.values,0,rotations,0,3);return;}
        if(e.sensor.getType()==Sensor.TYPE_ACCELEROMETER){
            filter.sample(t,e.values[0],e.values[1],e.values[2],rotations[0],rotations[1],rotations[2]);
        }else if(e.sensor.getType()==Sensor.TYPE_STEP_DETECTOR){
            filter.hardwareStep(t);
        }
    }
    @Override public void onAccuracyChanged(Sensor s,int accuracy){}
}
