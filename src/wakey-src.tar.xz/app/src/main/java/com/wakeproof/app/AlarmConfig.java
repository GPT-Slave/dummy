package com.wakeproof.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

final class AlarmConfig {
    String id=UUID.randomUUID().toString(), name="Wake up", startSound="default", tickSound="default", endSound="default";
    int hour=7,minute=0, seconds=30, days=127, volumeStart=75, volumeTick=50, volumeEnd=90;
    int eyeThreshold=75, walkMeters=6, strideCm=70, shakeTolerance=5;
    boolean enabled=true, vibrate=true;
    JSONObject json(){JSONObject j=new JSONObject();try{
        j.put("id",id);j.put("name",name);j.put("hour",hour);j.put("minute",minute);j.put("seconds",seconds);j.put("days",days);
        j.put("startSound",startSound);j.put("tickSound",tickSound);j.put("endSound",endSound);
        j.put("volumeStart",volumeStart);j.put("volumeTick",volumeTick);j.put("volumeEnd",volumeEnd);
        j.put("eyeThreshold",eyeThreshold);j.put("walkMeters",walkMeters);j.put("strideCm",strideCm);j.put("shakeTolerance",shakeTolerance);j.put("enabled",enabled);j.put("vibrate",vibrate);
    }catch(Exception ignored){}return j;}
    static AlarmConfig from(JSONObject j){AlarmConfig a=new AlarmConfig();a.id=j.optString("id",a.id);a.name=j.optString("name","Wake up");a.hour=j.optInt("hour",7);a.minute=j.optInt("minute",0);a.seconds=j.optInt("seconds",30);a.days=j.optInt("days",127);a.startSound=j.optString("startSound","default");a.tickSound=j.optString("tickSound","default");a.endSound=j.optString("endSound","default");a.volumeStart=j.optInt("volumeStart",75);a.volumeTick=j.optInt("volumeTick",50);a.volumeEnd=j.optInt("volumeEnd",90);a.eyeThreshold=j.optInt("eyeThreshold",75);a.walkMeters=Math.max(1,Math.min(50,j.optInt("walkMeters",6)));a.strideCm=Math.max(30,Math.min(110,j.optInt("strideCm",70)));a.shakeTolerance=Math.max(1,Math.min(10,j.optInt("shakeTolerance",5)));a.enabled=j.optBoolean("enabled",true);a.vibrate=j.optBoolean("vibrate",true);return a;}
    String cadence(){if(days==0)return "Once";if(days==127)return "Every day";if(days==31)return "Weekdays";if(days==96)return "Weekends";return "Custom days";}
}
final class AlarmStore {
    private static final String PREF="wakeproof.alarmstore";
    static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    static List<AlarmConfig> all(Context c){List<AlarmConfig> result=new ArrayList<>();try{JSONArray arr=new JSONArray(prefs(c).getString("alarms","[]"));for(int i=0;i<arr.length();i++)result.add(AlarmConfig.from(arr.getJSONObject(i)));}catch(Exception ignored){}return result;}
    static AlarmConfig find(Context c,String id){for(AlarmConfig a:all(c))if(a.id.equals(id))return a;return null;}
    static void put(Context c,AlarmConfig a){List<AlarmConfig> l=all(c);boolean found=false;for(int i=0;i<l.size();i++)if(l.get(i).id.equals(a.id)){l.set(i,a);found=true;break;}if(!found)l.add(a);store(c,l);}
    static void delete(Context c,String id){List<AlarmConfig> l=all(c);l.removeIf(a->a.id.equals(id));store(c,l);}
    private static void store(Context c,List<AlarmConfig> l){JSONArray a=new JSONArray();for(AlarmConfig x:l)a.put(x.json());prefs(c).edit().putString("alarms",a.toString()).apply();}
}
