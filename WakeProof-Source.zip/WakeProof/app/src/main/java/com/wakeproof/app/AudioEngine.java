package com.wakeproof.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.PowerManager;
import java.io.*;
import java.nio.*;

final class AudioEngine {
    private final Context c;
    private MediaPlayer start,tick,end;
    AudioEngine(Context c){this.c=c.getApplicationContext();}
    private File synth(int type) throws IOException {
        File f=new File(c.getCacheDir(),"wp-tone-v2-"+type+".wav");if(f.exists()&&f.length()>100)return f;
        int sr=22050;double duration=type==0?.75:type==1?.14:2.4;int n=(int)(sr*duration);
        ByteBuffer b=ByteBuffer.allocate(44+n*2).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes(java.nio.charset.StandardCharsets.US_ASCII));b.putInt(36+n*2);b.put("WAVEfmt ".getBytes(java.nio.charset.StandardCharsets.US_ASCII));
        b.putInt(16);b.putShort((short)1);b.putShort((short)1);b.putInt(sr);b.putInt(sr*2);b.putShort((short)2);b.putShort((short)16);b.put("data".getBytes(java.nio.charset.StandardCharsets.US_ASCII));b.putInt(n*2);
        for(int j=0;j<n;j++){double t=j/(double)sr;double wave;double attack=Math.min(1,t/.015),release=Math.min(1,(duration-t)/.06);double env=Math.max(0,Math.min(attack,release));
            if(type==0){double f0=t<.22?620:t<.45?780:990;wave=Math.sin(2*Math.PI*f0*t)*.39+Math.sin(2*Math.PI*2*f0*t)*.09;}
            else if(type==1){wave=(Math.sin(2*Math.PI*900*t)+.22*Math.sin(2*Math.PI*1800*t))*.34;}
            else{double hz=((int)(t/.29)%2==0)?620:850;wave=.41*Math.sin(2*Math.PI*hz*t)+.12*Math.sin(2*Math.PI*(hz*2.01)*t);env=Math.min(1,t/.035);}
            b.putShort((short)(Math.max(-1,Math.min(1,wave*env))*32767));
        }
        try(FileOutputStream out=new FileOutputStream(f)){out.write(b.array());}return f;
    }
    private MediaPlayer create(String sound,int type,int volume,boolean loop){if("silent".equals(sound))return null;
        MediaPlayer player=new MediaPlayer();try{
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            if(sound!=null&&sound.startsWith("content://"))player.setDataSource(c,Uri.parse(sound));else player.setDataSource(synth(type).getAbsolutePath());
            player.setWakeMode(c,PowerManager.PARTIAL_WAKE_LOCK);player.setLooping(loop);float amp=Math.max(0,Math.min(100,volume))/100f;player.setVolume(amp,amp);player.prepare();return player;
        }catch(Exception e){player.release();if(type==2&&sound!=null&&!sound.equals("default"))return create("default",type,volume,loop);return null;}
    }
    void playStart(AlarmConfig a){release(start);start=create(a.startSound,0,a.volumeStart,false);if(start!=null)start.start();}
    void tick(AlarmConfig a){if(tick==null)tick=create(a.tickSound,1,a.volumeTick,false);if(tick!=null){try{if(tick.isPlaying())tick.pause();tick.seekTo(0);tick.start();}catch(Exception ignored){}}}
    void finalLoop(AlarmConfig a){if(end!=null)return;release(start);release(tick);start=null;tick=null;end=create(a.endSound,2,a.volumeEnd,true);if(end!=null)end.start();}
    void preview(String sound,int type,int volume){stop();if(type==2){end=create(sound,type,volume,true);if(end!=null)end.start();}else if(type==1){tick=create(sound,type,volume,false);if(tick!=null)tick.start();}else{start=create(sound,type,volume,false);if(start!=null)start.start();}}
    void stop(){release(start);release(tick);release(end);start=null;tick=null;end=null;}
    private void release(MediaPlayer m){if(m==null)return;try{if(m.isPlaying())m.stop();}catch(Exception ignored){}try{m.release();}catch(Exception ignored){}}
}
