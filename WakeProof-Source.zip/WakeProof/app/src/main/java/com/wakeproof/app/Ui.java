package com.wakeproof.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

final class Ui {
    static final int BG=Color.rgb(16,18,23), CARD=Color.rgb(29,32,39), CARD2=Color.rgb(38,41,48);
    static final int WHITE=Color.rgb(247,247,240), MUTED=Color.rgb(158,163,170), LIME=Color.rgb(217,253,131);
    static final int RED=Color.rgb(255,129,120), STROKE=Color.rgb(54,58,65);
    static int dp(Context c,float n){return (int)(n*c.getResources().getDisplayMetrics().density+.5f);}
    static GradientDrawable bg(int color,int radius,int border){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);if(border!=0)g.setStroke(1,border);return g;}
    static LinearLayout column(Context c){LinearLayout v=new LinearLayout(c);v.setOrientation(1);return v;}
    static LinearLayout row(Context c){LinearLayout v=new LinearLayout(c);v.setOrientation(0);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    static TextView text(Context c,String s,int sp,int color,boolean bold){
        TextView v=new TextView(c);v.setText(s);v.setTextColor(color);v.setTextSize(sp);v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));return v;
    }
    static TextView label(Context c,String s){TextView t=text(c,s.toUpperCase(),11,MUTED,true);t.setLetterSpacing(.17f);return t;}
    static LinearLayout card(Context c){LinearLayout x=column(c);x.setPadding(dp(c,20),dp(c,20),dp(c,20),dp(c,20));x.setBackground(bg(CARD,dp(c,22),STROKE));return x;}
    static void space(LinearLayout parent, Context c,int h){View v=new View(c);parent.addView(v,new LinearLayout.LayoutParams(1,dp(c,h)));}
    static void spaceHorizontal(LinearLayout parent,Context c,int w){parent.addView(new View(c),new LinearLayout.LayoutParams(dp(c,w),1));}
    static void add(LinearLayout p,View v){p.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    static void addMargin(LinearLayout p,View v,int top){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(p.getContext(),top);p.addView(v,lp);}
    static TextView button(Context c,String title,boolean primary){TextView v=text(c,title,14,primary?BG:WHITE,true);v.setGravity(Gravity.CENTER);v.setLetterSpacing(.045f);v.setPadding(dp(c,16),dp(c,17),dp(c,16),dp(c,17));v.setBackground(bg(primary?LIME:CARD2,dp(c,16),primary?0:STROKE));v.setClickable(true);v.setFocusable(true);return v;}
    static TextView pill(Context c,String title){TextView v=text(c,title,12,MUTED,true);v.setPadding(dp(c,12),dp(c,8),dp(c,12),dp(c,8));v.setBackground(bg(CARD2,dp(c,22),STROKE));return v;}
    static EditText input(Context c,String value){EditText x=new EditText(c);x.setSingleLine(true);x.setText(value);x.setTextColor(WHITE);x.setHintTextColor(MUTED);x.setTextSize(17);x.setSelectAllOnFocus(false);x.setPadding(dp(c,12),dp(c,10),dp(c,12),dp(c,10));x.setBackground(bg(CARD2,dp(c,12),STROKE));return x;}
    static SeekBar seek(Context c,int max,int value){SeekBar s=new SeekBar(c);s.setMax(max);s.setProgress(value);s.setProgressTintList(ColorStateList.valueOf(LIME));s.setThumbTintList(ColorStateList.valueOf(LIME));s.setProgressBackgroundTintList(ColorStateList.valueOf(STROKE));return s;}
    static Switch toggle(Context c,boolean checked){Switch sw=new Switch(c);sw.setChecked(checked);sw.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{LIME,MUTED}));return sw;}
    static LinearLayout screen(Activity a){
        a.getWindow().setStatusBarColor(BG);a.getWindow().setNavigationBarColor(BG);
        LinearLayout root=column(a);root.setBackgroundColor(BG);
        ScrollView sc=new ScrollView(a);sc.setFillViewport(true);sc.setClipToPadding(false);sc.setVerticalScrollBarEnabled(false);
        LinearLayout body=column(a);body.setPadding(dp(a,22),dp(a,25),dp(a,22),dp(a,36));sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,-1));a.setContentView(root);return body;
    }
    static void heading(LinearLayout target,String left,String right){Context c=target.getContext();LinearLayout r=row(c);TextView a=label(c,left);r.addView(a,new LinearLayout.LayoutParams(0,-2,1));r.addView(text(c,right,12,MUTED,false));add(target,r);}
    static void toast(Context c,String s){Toast.makeText(c,s,Toast.LENGTH_LONG).show();}
    static String time(int hour,int minute){return String.format(java.util.Locale.getDefault(),"%02d:%02d",hour,minute);}
}
