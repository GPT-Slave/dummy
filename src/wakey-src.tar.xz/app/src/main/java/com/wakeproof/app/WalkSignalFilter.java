package com.wakeproof.app;

/**
 * Orientation-independent pedometer core. The raw accelerometer estimator runs
 * EVEN when the device advertises a hardware step sensor that never emits data.
 * The independent counts are merged using max(), never summed.
 */
final class WalkSignalFilter {
    interface Listener { void changed(); }
    private final int tolerance;
    private final Listener listener;
    int accepted, rejected, candidates, shakeEvents;
    float acceleration, spin;
    String reason = "Waiting for motion samples";
    private long firstSampleMs, lastSampleMs, lastSoftPeakMs, lastHardwareMs, lastShakeMs;
    private float gravity = 9.81f, wave, previousWave, gyroSmooth;
    private boolean peakArmed = true;
    private int softStreak, unconfirmedSoft, softwareSteps, detectorSteps, counterSteps, samples;
    private float counterBaseline = Float.NaN;

    WalkSignalFilter(int shakeTolerance, boolean hasStepSensor, Listener listener) {
        tolerance = Math.max(1, Math.min(10, shakeTolerance));
        this.listener = listener;
    }

    void sample(long timeMs, float ax, float ay, float az, float gx, float gy, float gz) {
        float magnitude = (float)Math.sqrt(ax * ax + ay * ay + az * az);
        float gyro = (float)Math.sqrt(gx * gx + gy * gy + gz * gz);
        if (firstSampleMs == 0) firstSampleMs = timeMs;
        if (timeMs <= lastSampleMs && lastSampleMs != 0) return;
        lastSampleMs = timeMs;
        samples++;
        // Gravity low-pass and a band-limited magnitude wave: phone orientation
        // does not need to be fixed and both pockets and hands work.
        gravity += .038f * (magnitude - gravity);
        float linear = magnitude - gravity;
        wave = .66f * wave + .34f * linear;
        acceleration = .8f * acceleration + .2f * Math.abs(linear);
        gyroSmooth = .8f * gyroSmooth + .2f * gyro;
        spin = gyroSmooth;

        // Avoid prolonged lockouts: a vigorous but real footfall must not
        // disqualify the next two seconds of normal walking.
        float violent = 6.0f + tolerance * .55f;
        float spinning = 2.8f + tolerance * .30f;
        if (Math.abs(linear) > violent || gyro > spinning) {
            if (timeMs - lastShakeMs > 400) shakeEvents++;
            lastShakeMs = timeMs;
            reason = "Abrupt shake / rotation; checking walking cadence";
        }

        // Peak + trough (hysteresis) + human walking cadence. Need three
        // consistent peaks to reject one-off gestures and knocks.
        float high = .25f + (10 - tolerance) * .045f;
        if (wave < -.14f) peakArmed = true;
        if (peakArmed && wave > high && previousWave <= high) {
            peakArmed = false;
            softwarePeak(timeMs, Math.abs(linear) > violent || gyro > spinning);
        }
        previousWave = wave;
    }

    private void softwarePeak(long t, boolean violentNow) {
        candidates++;
        long interval = lastSoftPeakMs == 0 ? 0 : t - lastSoftPeakMs;
        lastSoftPeakMs = t;
        if (violentNow || (lastShakeMs != 0 && t - lastShakeMs < 220)) {
            rejected++;
            softStreak = 0;
            unconfirmedSoft = 0;
            reason = "Impact / rotation too abrupt for walking";
            inform();
            return;
        }
        if (interval != 0 && interval < 320) {
            rejected++;
            softStreak = 0;
            unconfirmedSoft = 0;
            reason = "Motion pulses too rapid for walking";
            inform();
            return;
        }
        if (interval == 0 || interval > 1650) {
            softStreak = 1;
            unconfirmedSoft = 1;
        } else {
            softStreak++;
            unconfirmedSoft++;
        }
        if (softStreak >= 3) {
            softwareSteps += unconfirmedSoft;
            unconfirmedSoft = 0;
            reason = "Walking cadence confirmed";
        } else reason = "Finding walking rhythm (" + softStreak + "/3)";
        merge();
    }

    /** TYPE_STEP_DETECTOR events report discrete steps. */
    void hardwareStep(long t) {
        candidates++;
        // Hardware pedometer already classifies gait. Do NOT veto its events
        // based on an arbitrary acceleration threshold as the old code did.
        if (lastShakeMs != 0 && t - lastShakeMs < 200) {
            rejected++;
            reason = "Strong rotation; hardware pulse ignored";
            inform();
            return;
        }
        if (lastHardwareMs != 0 && t - lastHardwareMs < 260) {
            rejected++;
            reason = "Duplicate pedometer pulse";
            inform();
            return;
        }
        detectorSteps++;
        lastHardwareMs = t;
        reason = "Android pedometer detected a step";
        merge();
    }

    /** TYPE_STEP_COUNTER cumulative value starts at an arbitrary baseline. */
    void hardwareCounter(long t, float count) {
        if (Float.isNaN(count) || count < 0) return;
        if (Float.isNaN(counterBaseline) || count < counterBaseline) {
            counterBaseline = count;
            counterSteps = 0;
            return;
        }
        int relative = Math.max(0, Math.round(count - counterBaseline));
        if (relative > counterSteps) {
            candidates += relative - counterSteps;
            counterSteps = relative;
            lastHardwareMs = t;
            reason = "Android step counter updated";
            merge();
        }
    }

    private void merge() {
        int next = Math.max(softwareSteps, Math.max(detectorSteps, counterSteps));
        if (next > accepted) accepted = next;
        inform();
    }
    private void inform() { if (listener != null) listener.changed(); }
    int steps() { return accepted; }
    long lastSampleMs() { return lastSampleMs; }
    int samples() { return samples; }
    boolean hardwareReported() { return detectorSteps > 0 || counterSteps > 0; }
    int hardwareCount() { return Math.max(detectorSteps, counterSteps); }
    int softwareCount() { return softwareSteps; }
}
