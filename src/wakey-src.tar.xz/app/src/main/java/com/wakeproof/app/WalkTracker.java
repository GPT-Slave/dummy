package com.wakeproof.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.*;
import android.os.Build;
import android.os.SystemClock;

/** Shared motion measurement used by both the alarm foreground service and Sensor Lab. */
final class WalkTracker implements SensorEventListener {
    interface Update { void onWalkUpdate(); }
    private final Context context;
    private final AlarmConfig config;
    private final SensorManager sensors;
    private final Sensor accelerometer, gyro, detector, counter;
    private final WalkSignalFilter filter;
    private final Update callback;
    private final float[] rotations = new float[3];
    private boolean started, detectorRegistered, counterRegistered, accelRegistered;
    private int seedSteps;

    WalkTracker(Context c, AlarmConfig a, Update listener) {
        context = c; config = a; callback = listener;
        sensors = (SensorManager)c.getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyro = sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        detector = sensors.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        counter = sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        filter = new WalkSignalFilter(a.shakeTolerance, detector != null || counter != null,
            () -> { if (callback != null) callback.onWalkUpdate(); });
    }

    static boolean hasPermission(Context c) {
        return Build.VERSION.SDK_INT < 29 || c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
    }
    boolean supportsHardware() { return detector != null || counter != null; }
    boolean canTrack() { return accelerometer != null || (hasPermission(context) && supportsHardware()); }
    boolean usingHardware() { return detectorRegistered || counterRegistered; }
    boolean start() {
        if (started) return true;
        if (!canTrack()) return false;
        // Always register the accelerometer: it provides a fallback on devices
        // that advertise a dormant/unreliable step detector.
        if (accelerometer != null) accelRegistered = sensors.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        if (gyro != null) sensors.registerListener(this, gyro, SensorManager.SENSOR_DELAY_GAME);
        if (hasPermission(context)) {
            if (detector != null) detectorRegistered = sensors.registerListener(this, detector, SensorManager.SENSOR_DELAY_NORMAL);
            if (counter != null) counterRegistered = sensors.registerListener(this, counter, SensorManager.SENSOR_DELAY_NORMAL);
        }
        started = accelRegistered || detectorRegistered || counterRegistered;
        if (!started) sensors.unregisterListener(this);
        return started;
    }
    void stop() { sensors.unregisterListener(this); started = false; }
    boolean isRunning() { return started; }
    void seed(int stepCount) { seedSteps = Math.max(0, stepCount); }
    int steps() { return seedSteps + filter.steps(); }
    int rejected() { return filter.rejected; }
    int candidates() { return filter.candidates; }
    int shakes() { return filter.shakeEvents; }
    double meters() { return steps() * config.strideCm / 100.0; }
    boolean complete() { return meters() + 1e-5 >= config.walkMeters; }
    String reason() { return filter.reason; }
    String sensorMode() {
        if (!started) return "Motion sensors unavailable";
        long latest = filter.lastSampleMs();
        if (accelRegistered && latest == 0) return "Listening for accelerometer data…";
        if (accelRegistered && SystemClock.elapsedRealtime() - latest > 3000) return "Accelerometer not delivering data";
        String source = filter.hardwareReported() ? "Android pedometer" : "Accelerometer walking fallback";
        String hardware = usingHardware() ? " · hardware available" : " · no hardware step feed";
        return source + hardware + " · " + filter.samples() + " samples";
    }
    float impact() { return filter.acceleration; }
    float rotation() { return filter.spin; }
    int rawSoftwareSteps() { return filter.softwareCount(); }
    int rawHardwareSteps() { return filter.hardwareCount(); }

    @Override public void onSensorChanged(SensorEvent e) {
        long timeMs = e.timestamp / 1_000_000L;
        switch (e.sensor.getType()) {
            case Sensor.TYPE_GYROSCOPE:
                System.arraycopy(e.values, 0, rotations, 0, 3);
                break;
            case Sensor.TYPE_ACCELEROMETER:
                filter.sample(timeMs, e.values[0], e.values[1], e.values[2], rotations[0], rotations[1], rotations[2]);
                break;
            case Sensor.TYPE_STEP_DETECTOR:
                filter.hardwareStep(timeMs);
                break;
            case Sensor.TYPE_STEP_COUNTER:
                filter.hardwareCounter(timeMs, e.values[0]);
                break;
        }
    }
    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}
