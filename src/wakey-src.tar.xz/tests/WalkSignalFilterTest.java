package com.wakeproof.app;

/** Offline deterministic regression tests. Run with the JDK; no Android device needed. */
public final class WalkSignalFilterTest {
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    private static void feed(WalkSignalFilter f, int start, int durationMs, double frequency, double amplitude, float rotation) {
        for (long ms=start; ms<start+durationMs; ms+=20) {
            double t=(ms-start)/1000.;
            f.sample(ms, .08f, .09f, (float)(9.81 + amplitude*Math.sin(2*Math.PI*frequency*t)), rotation, rotation*.12f, rotation*.10f);
        }
    }
    public static void main(String[] args) {
        WalkSignalFilter fallback = new WalkSignalFilter(5, true, () -> {});
        // Advertise a hardware sensor but never deliver a step callback: the old bug.
        feed(fallback, 1000, 12000, 1.7, 1.3, .24f);
        check(fallback.steps() >= 12, "Software fallback must count even if hardware is silent: " + fallback.steps());

        WalkSignalFilter quiet = new WalkSignalFilter(5, false, () -> {});
        for (long t=1000; t<9000; t+=20) quiet.sample(t, 0, 0, 9.81f, 0, 0, 0);
        check(quiet.steps()==0, "Still phone should never count steps");

        WalkSignalFilter highRotationShake = new WalkSignalFilter(5, true, () -> {});
        for (long t=1000; t<12000; t+=20) {
            double wave=(t-1000)/1000.0;
            highRotationShake.sample(t, 0, 0, (float)(9.81+12*Math.sin(2*Math.PI*4*wave)), 5,2,1);
            if(t%500==0) highRotationShake.hardwareStep(t);
        }
        check(highRotationShake.steps()==0, "Strong shaking must not register: " + highRotationShake.steps());
        check(highRotationShake.rejected>0, "Shaking must be shown as rejected");

        WalkSignalFilter hardware = new WalkSignalFilter(5, true, () -> {});
        // Little acceleration evidence (e.g. stable phone in pocket); hardware sensor still valid.
        for (long ms=1000;ms<11500;ms+=20) {
            hardware.sample(ms,0,0,9.81f,.06f,.03f,.03f);
            if(ms%700==0) hardware.hardwareStep(ms);
        }
        check(hardware.steps()>=10, "Hardware steps must not require a fixed impact threshold: " +hardware.steps());

        WalkSignalFilter counter = new WalkSignalFilter(5, true, () -> {});
        counter.hardwareCounter(1000,1233f); // baseline; not steps since boot
        check(counter.steps()==0,"Counter baseline must not award false steps");
        counter.hardwareCounter(4000,1241f);
        check(counter.steps()==8,"Cumulative counter delta must count: "+counter.steps());

        WalkSignalFilter both = new WalkSignalFilter(5, true, () -> {});
        for(long t=1000;t<11000;t+=20){
            double v=(t-1000)/1000.0;
            both.sample(t,0,0,(float)(9.81+1.3*Math.sin(2*Math.PI*1.5*v)),.15f,.15f,.15f);
            if(t%1000==0) both.hardwareStep(t);
        }
        check(both.steps()>=10 && both.steps()<24,"Parallel sources must not be added: "+both.steps());

        WalkSignalFilter tooFast = new WalkSignalFilter(5, false, () -> {});
        feed(tooFast,1000,7000,5.0,1.5,.2f);
        check(tooFast.steps()==0,"Fast shaking pulses must not be counted: "+tooFast.steps());
        check(tooFast.rejected>0,"Shake candidate rejects should show in lab");

        System.out.println("PASS: silent-hardware fallback="+fallback.steps()+", hardware="+hardware.steps()+
            ", counter="+counter.steps()+", mixed="+both.steps()+", shake="+highRotationShake.steps());
    }
}
