package com.wakeproof.app;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;

public class EditActivity extends Activity {
    private AlarmConfig a;
    private EditText title;
    private TextView time, durationText, thresholdText;
    private AudioEngine preview;
    private LinearLayout dayRow;
    private TextView[] dayButtons=new TextView[7];
    private TextView[] audioNames=new TextView[3];
    private int chosenSound=0;
    @Override public void onCreate(Bundle state){super.onCreate(state);
        String id=getIntent().getStringExtra("id");a=id==null?null:AlarmStore.find(this,id);if(a==null)a=new AlarmConfig();
        preview=new AudioEngine(this);render();
    }
    private void render(){LinearLayout page=Ui.screen(this);
        TextView back=Ui.text(this,"‹    BACK TO ALARMS",13,Ui.MUTED,true);back.setOnClickListener(v->finish());Ui.add(page,back);Ui.space(page,this,24);
        Ui.add(page,Ui.text(this,"Make it yours.",35,Ui.WHITE,true));Ui.space(page,this,6);
        Ui.add(page,Ui.text(this,"Every detail, right down to the last second.",14,Ui.MUTED,false));Ui.space(page,this,27);
        Ui.add(page,Ui.label(this,"ALARM TIME"));Ui.space(page,this,10);
        time=Ui.text(this,Ui.time(a.hour,a.minute)+"   ↗",58,Ui.WHITE,true);time.setBackground(Ui.bg(Ui.CARD,Ui.dp(this,21),Ui.STROKE));time.setPadding(Ui.dp(this,17),Ui.dp(this,16),Ui.dp(this,12),Ui.dp(this,16));
        time.setOnClickListener(v->new TimePickerDialog(this,(picker,h,m)->{a.hour=h;a.minute=m;time.setText(Ui.time(h,m)+"   ↗");},a.hour,a.minute,true).show());Ui.add(page,time);Ui.space(page,this,22);
        Ui.add(page,Ui.label(this,"ALARM NAME"));Ui.space(page,this,10);title=Ui.input(this,a.name);Ui.add(page,title);Ui.space(page,this,25);
        Ui.heading(page,"REPEAT","NONE = ONE-TIME");Ui.space(page,this,10);
        LinearLayout presets=Ui.row(this);String[] labels={"ONCE","DAILY","MON–FRI","WEEKENDS"};int[] masks={0,127,31,96};
        for(int i=0;i<labels.length;i++){final int mask=masks[i];TextView b=Ui.pill(this,labels[i]);b.setTextSize(10);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.rightMargin=Ui.dp(this,i==3?0:5);presets.addView(b,lp);
            b.setGravity(Gravity.CENTER);b.setOnClickListener(v->{a.days=mask;refreshDays();});}
        Ui.add(page,presets);Ui.space(page,this,11);
        dayRow=Ui.row(this);String[] days={"M","T","W","T","F","S","S"};for(int i=0;i<7;i++){
            final int idx=i;TextView b=Ui.text(this,days[i],13,Ui.WHITE,true);b.setGravity(Gravity.CENTER);b.setPadding(0,Ui.dp(this,11),0,Ui.dp(this,11));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.rightMargin=Ui.dp(this,i==6?0:6);dayRow.addView(b,lp);dayButtons[i]=b;
            b.setOnClickListener(v->{a.days^=(1<<idx);refreshDays();});
        }Ui.add(page,dayRow);refreshDays();Ui.space(page,this,27);
        LinearLayout countdown=Ui.card(this);Ui.heading(countdown,"COUNTDOWN LENGTH","5–180 SECONDS");Ui.space(countdown,this,13);
        durationText=Ui.text(this,a.seconds+" seconds",25,Ui.WHITE,true);Ui.add(countdown,durationText);
        SeekBar duration=Ui.seek(this,35,Math.max(0,(a.seconds-5)/5));duration.setOnSeekBarChangeListener(change(p->{a.seconds=5+p*5;durationText.setText(a.seconds+" seconds");}));Ui.add(countdown,duration);
        Ui.add(countdown,Ui.text(this,"The final sound begins when the timer reaches 00.",12,Ui.MUTED,false));Ui.add(page,countdown);Ui.space(page,this,24);
        Ui.add(page,Ui.label(this,"THE SOUND DESIGN"));Ui.space(page,this,5);
        Ui.add(page,Ui.text(this,"Choose a different audio file and volume for each stage.",13,Ui.MUTED,false));Ui.space(page,this,11);
        soundCard(page,0,"01   START SIGNAL","The moment the alarm fires");
        soundCard(page,1,"02   COUNTDOWN TICK","Plays once per second");
        soundCard(page,2,"03   FINAL SIREN","Loops until your selfie is verified");
        Ui.space(page,this,12);
        LinearLayout verify=Ui.card(this);Ui.add(verify,Ui.label(this,"EYE-OPEN CONFIDENCE"));Ui.space(verify,this,12);
        thresholdText=Ui.text(this,a.eyeThreshold+"% required",23,Ui.WHITE,true);Ui.add(verify,thresholdText);
        SeekBar threshold=Ui.seek(this,40,a.eyeThreshold-55);
        threshold.setOnSeekBarChangeListener(change(p->{a.eyeThreshold=p+55;thresholdText.setText(a.eyeThreshold+"% required");}));Ui.add(verify,threshold);
        Ui.add(verify,Ui.text(this,"Both eyes must be visible, open, and facing the camera. Higher means stricter.",12,Ui.MUTED,false));Ui.space(verify,this,17);
        LinearLayout vibrate=Ui.row(this);vibrate.addView(Ui.text(this,"Vibrate when ringing",15,Ui.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));Switch sw=Ui.toggle(this,a.vibrate);sw.setOnCheckedChangeListener((b,x)->a.vibrate=x);vibrate.addView(sw);Ui.add(verify,vibrate);Ui.add(page,verify);
        Ui.space(page,this,23);
        TextView save=Ui.button(this,"SAVE ALARM  ↗",true);save.setOnClickListener(v->save());Ui.add(page,save);
        if(AlarmStore.find(this,a.id)!=null){Ui.space(page,this,12);TextView delete=Ui.button(this,"DELETE ALARM",false);delete.setTextColor(Ui.RED);
            delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete this alarm?").setMessage("You can always make another one.").setNegativeButton("Keep",null)
                    .setPositiveButton("Delete",(d,w)->{a.enabled=false;AlarmScheduler.schedule(this,a);AlarmStore.delete(this,a.id);finish();}).show());Ui.add(page,delete);}
        Ui.space(page,this,18);Ui.add(page,Ui.text(this,"Camera verification happens only when the alarm rings. No photo leaves your phone.",12,Ui.MUTED,false));
    }
    private void refreshDays(){for(int i=0;i<7;i++){boolean selected=(a.days&(1<<i))!=0;dayButtons[i].setBackground(Ui.bg(selected?Ui.LIME:Ui.CARD2,Ui.dp(this,10),selected?0:Ui.STROKE));dayButtons[i].setTextColor(selected?Ui.BG:Ui.MUTED);}}
    private static SeekBar.OnSeekBarChangeListener change(java.util.function.IntConsumer consumer){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean fromUser){if(fromUser)consumer.accept(p);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}};}
    private void soundCard(LinearLayout page,int part,String label,String description){LinearLayout card=Ui.card(this);Ui.add(card,Ui.label(this,label));Ui.space(card,this,8);Ui.add(card,Ui.text(this,description,13,Ui.MUTED,false));Ui.space(card,this,13);
        LinearLayout select=Ui.row(this);String value=part==0?a.startSound:part==1?a.tickSound:a.endSound;
        TextView name=Ui.text(this,value.startsWith("content://")?"Custom audio file":"Built-in sound",15,Ui.WHITE,true);audioNames[part]=name;select.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView choose=Ui.pill(this,"CHANGE");select.addView(choose);choose.setOnClickListener(v->choose(part));Ui.add(card,select);Ui.space(card,this,11);
        int volume=part==0?a.volumeStart:part==1?a.volumeTick:a.volumeEnd;
        TextView vol=Ui.text(this,"VOLUME     "+volume+"%",11,Ui.MUTED,true);Ui.add(card,vol);
        SeekBar seek=Ui.seek(this,100,volume);seek.setOnSeekBarChangeListener(change(p->{if(part==0)a.volumeStart=p;else if(part==1)a.volumeTick=p;else a.volumeEnd=p;vol.setText("VOLUME     "+p+"%");}));Ui.add(card,seek);
        LinearLayout actions=Ui.row(this);TextView play=Ui.pill(this,"▶  PREVIEW");TextView reset=Ui.pill(this,"RESET SOUND");play.setOnClickListener(v->{preview.preview(part==0?a.startSound:part==1?a.tickSound:a.endSound,part,part==0?a.volumeStart:part==1?a.volumeTick:a.volumeEnd);if(part==2)new Handler(Looper.getMainLooper()).postDelayed(()->preview.stop(),2300);});
        reset.setOnClickListener(v->{if(part==0)a.startSound="default";else if(part==1)a.tickSound="default";else a.endSound="default";name.setText("Built-in sound");preview.stop();});
        actions.addView(play);Ui.spaceHorizontal(actions,this,9);actions.addView(reset);Ui.add(card,actions);Ui.addMargin(page,card,10);
    }
    private void choose(int part){chosenSound=part;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,100+part);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null||request<100||request>102)return;
        Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        int part=request-100;if(part==0)a.startSound=uri.toString();else if(part==1)a.tickSound=uri.toString();else a.endSound=uri.toString();audioNames[part].setText("Custom audio file");}
    private void save(){a.name=title.getText().toString().trim();if(a.name.isEmpty())a.name="Wake up";
        AlarmStore.put(this,a);AlarmScheduler.schedule(this,a);
        if(!AlarmScheduler.allowed(this))AlarmScheduler.permission(this);
        Ui.toast(this,"Alarm saved");finish();
    }
    @Override protected void onPause(){super.onPause();preview.stop();}
    @Override protected void onDestroy(){preview.stop();super.onDestroy();}
}
