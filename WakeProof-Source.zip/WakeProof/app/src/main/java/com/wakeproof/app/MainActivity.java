package com.wakeproof.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout page;
    @Override public void onCreate(Bundle b){super.onCreate(b);if(Build.VERSION.SDK_INT>=33&&!getPreferences(0).getBoolean("notificationsAsked",false)){
            getPreferences(0).edit().putBoolean("notificationsAsked",true).apply();requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},41);
        } }
    @Override protected void onResume(){super.onResume();render();}
    private void render(){page=Ui.screen(this);Ui.add(page,Ui.label(this,"W / P     YOUR MORNING, YOUR RULES"));Ui.space(page,this,20);
        Ui.add(page,Ui.text(this,"WakeProof.",39,Ui.WHITE,true));Ui.space(page,this,6);
        Ui.add(page,Ui.text(this,"An alarm you have to face.",16,Ui.MUTED,false));Ui.space(page,this,27);
        if(AlarmService.active(this)){
            LinearLayout active=Ui.card(this);active.setBackground(Ui.bg(Ui.LIME,Ui.dp(this,23),0));
            Ui.add(active,Ui.text(this,"YOUR ALARM IS RINGING",11,Ui.BG,true));Ui.space(active,this,9);
            Ui.add(active,Ui.text(this,"Time to prove you're awake.",22,Ui.BG,true));Ui.space(active,this,15);
            TextView btn=Ui.button(this,"OPEN SELFIE CHALLENGE",false);btn.setTextColor(Ui.WHITE);btn.setOnClickListener(v->startActivity(new Intent(this,RingActivity.class)));Ui.add(active,btn);Ui.add(page,active);Ui.space(page,this,23);
        }
        AlarmConfig upcoming=null;long nearest=Long.MAX_VALUE;for(AlarmConfig a:AlarmStore.all(this))if(a.enabled){long t=AlarmScheduler.next(a);if(t>0&&t<nearest){nearest=t;upcoming=a;}}
        LinearLayout overview=Ui.card(this);Ui.add(overview,Ui.label(this,"NEXT ALARM"));Ui.space(overview,this,18);
        if(upcoming==null){Ui.add(overview,Ui.text(this,"— — : — —",43,Ui.WHITE,true));Ui.space(overview,this,6);Ui.add(overview,Ui.text(this,"Nothing scheduled yet. Make your first one.",14,Ui.MUTED,false));}
        else{Ui.add(overview,Ui.text(this,Ui.time(upcoming.hour,upcoming.minute),56,Ui.WHITE,true));Ui.space(overview,this,4);Ui.add(overview,Ui.text(this,upcoming.name+"  ·  "+upcoming.cadence(),14,Ui.MUTED,false));
            Ui.space(overview,this,14);Ui.add(overview,Ui.pill(this,new SimpleDateFormat("EEE, d MMM · h:mm a",Locale.getDefault()).format(new Date(nearest))));}
        Ui.add(page,overview);Ui.space(page,this,16);
        TextView add=Ui.button(this,"+    CREATE NEW ALARM",true);add.setOnClickListener(v->startActivity(new Intent(this,EditActivity.class)));Ui.add(page,add);Ui.space(page,this,32);
        Ui.heading(page,"YOUR ALARMS",AlarmStore.all(this).size()+" TOTAL");Ui.space(page,this,12);
        List<AlarmConfig> configs=AlarmStore.all(this);
        for(AlarmConfig alarm:configs){LinearLayout item=Ui.card(this);LinearLayout top=Ui.row(this);
            LinearLayout labels=Ui.column(this);Ui.add(labels,Ui.text(this,Ui.time(alarm.hour,alarm.minute),34,alarm.enabled?Ui.WHITE:Ui.MUTED,true));Ui.space(labels,this,4);
            Ui.add(labels,Ui.text(this,alarm.name+"  /  "+alarm.cadence(),13,Ui.MUTED,false));top.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
            Switch enabled=Ui.toggle(this,alarm.enabled);top.addView(enabled);enabled.setOnCheckedChangeListener((s,checked)->{
                if(checked&&!AlarmScheduler.allowed(this)){enabled.setChecked(false);AlarmScheduler.permission(this);return;}
                alarm.enabled=checked;AlarmStore.put(this,alarm);AlarmScheduler.schedule(this,alarm);render();
            });Ui.add(item,top);Ui.space(item,this,16);
            TextView detail=Ui.text(this,alarm.seconds+"s countdown     ·     "+alarm.eyeThreshold+"% eye confidence",12,Ui.MUTED,false);Ui.add(item,detail);Ui.space(item,this,15);
            LinearLayout controls=Ui.row(this);TextView edit=Ui.button(this,"EDIT",false);TextView tryAlarm=Ui.button(this,"TRY NOW",false);
            controls.addView(edit,new LinearLayout.LayoutParams(0,-2,1));Ui.spaceHorizontal(controls,this,10);controls.addView(tryAlarm,new LinearLayout.LayoutParams(0,-2,1));
            edit.setOnClickListener(v->startActivity(new Intent(this,EditActivity.class).putExtra("id",alarm.id)));
            tryAlarm.setOnClickListener(v->startTest(alarm));Ui.add(item,controls);Ui.addMargin(page,item,10);
        }
        Ui.space(page,this,27);
        if(!AlarmScheduler.allowed(this)){
            TextView permission=Ui.button(this,"ALLOW EXACT ALARMS",false);permission.setOnClickListener(v->AlarmScheduler.permission(this));Ui.add(page,permission);Ui.space(page,this,12);
            Ui.add(page,Ui.text(this,"Exact alarms require Android's Alarms & reminders access.",12,Ui.MUTED,false));Ui.space(page,this,15);
        }
        if(Build.VERSION.SDK_INT>=34){NotificationManager nm=getSystemService(NotificationManager.class);if(!nm.canUseFullScreenIntent()){
            TextView full=Ui.button(this,"ENABLE FULL-SCREEN ALARMS",false);
            full.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).setData(android.net.Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}});
            Ui.add(page,full);Ui.space(page,this,12);
        }}
        Ui.add(page,Ui.text(this,"Selfies are checked on your device and never uploaded. Android's system alarm volume and battery settings still apply.",12,Ui.MUTED,false));
    }
    private void startTest(AlarmConfig a){if(AlarmService.active(this)){startActivity(new Intent(this,RingActivity.class));return;}
        Intent i=new Intent(this,AlarmService.class).setAction(AlarmService.TEST).putExtra("id",a.id);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        startActivity(new Intent(this,RingActivity.class));
    }
}
