package com.wakeproof.app;

/** Pure-Java step plausibility filter: deterministic, replayable and independent of UI. */
final class WalkSignalFilter {
    interface Listener { void changed(); }
    private final int sensitivity;  // 1 = strict, 10 = permissive
    private final boolean hardwareSteps;
    private final Listener listener;
    int accepted, rejected, candidates, shakeEvents;
    float acceleration, spin;
    String reason="Waiting for movement";
    private long lastMotionMs=0, lastCandidateMs=0, lastGoodMs=0, shakeUntilMs=0;
    private float gravity=9.81f, smoothedDelta=0f, formerDelta=0f;
    private boolean peakArmed=true;
    private int walkingStreak=0, pendingSteps=0;

    WalkSignalFilter(int sensitivity, boolean hardwareSteps, Listener listener) {
        this.sensitivity=Math.max(1,Math.min(10,sensitivity));
        this.hardwareSteps=hardwareSteps;this.listener=listener;
    }
    void sample(long tMs,float ax,float ay,float az,float gx,float gy,float gz){
        float mag=(float)Math.sqrt(ax*ax+ay*ay+az*az);
        gravity=gravity*.985f+mag*.015f;
        float delta=Math.abs(mag-gravity);
        acceleration=acceleration*.75f+delta*.25f;
        float gyro=(float)Math.sqrt(gx*gx+gy*gy+gz*gz);
        spin=spin*.7f+gyro*.3f;
        lastMotionMs=tMs;
        float accelLimit=3.8f+sensitivity*.57f;
        float spinLimit=1.9f+sensitivity*.26f;
        if(delta>accelLimit || gyro>spinLimit){
            if(tMs>shakeUntilMs){shakeEvents++;listener.changed();}
            shakeUntilMs=tMs+850;reason="Shake-like motion rejected";
        }
        // Software walking-step fallback for devices without a dedicated step sensor.
        // Uses a slow/fast filter and a trough between peaks to prevent one jerk yielding many steps.
        if(!hardwareSteps){
            smoothedDelta=.78f*smoothedDelta+.22f*(mag-gravity);
            if(smoothedDelta<-.20f)peakArmed=true;
            if(peakArmed && smoothedDelta>.75f && formerDelta<=.75f){
                peakArmed=false;candidate(tMs);
            }
            formerDelta=smoothedDelta;
        }
    }
    void hardwareStep(long tMs){if(hardwareSteps)candidate(tMs);}
    private void candidate(long tMs){
        candidates++;
        if(tMs-lastCandidateMs<330){reject("Too fast to be a walking step");return;}
        lastCandidateMs=tMs;
        if(lastMotionMs==0 || Math.abs(tMs-lastMotionMs)>1500){reject("No recent accelerometer evidence");return;}
        if(tMs<shakeUntilMs){walkingStreak=0;pendingSteps=0;reject("Shake/rotation detected");return;}
        if(acceleration<.11f){reject("No walking impact detected");return;}
        if(tMs-lastGoodMs>2500){walkingStreak=0;pendingSteps=0;}
        lastGoodMs=tMs;
        walkingStreak++;
        pendingSteps++;
        if(walkingStreak>=3){
            accepted+=pendingSteps;pendingSteps=0;
            reason="Walking confirmed";
        }else reason="Checking walking rhythm ("+walkingStreak+"/3)";
        listener.changed();
    }
    private void reject(String msg){rejected++;reason=msg;listener.changed();}
    int steps(){return accepted;}
}
