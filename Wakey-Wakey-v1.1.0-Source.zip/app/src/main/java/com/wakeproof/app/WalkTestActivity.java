package com.wakeproof.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.Gravity;
import android.widget.*;
import java.util.Locale;

/** Sensor laboratory: the same tracker and thresholds used during an actual alarm. */
public class WalkTestActivity extends Activity {
    private AlarmConfig config;
    private WalkTracker tracker;
    private LinearLayout page;
    private TextView meterLabel,stepLabel,signalLabel,insightLabel,reportLabel,modeLabel,runLabel;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int mode=0, startAccepted=0,startRejected=0,startShakes=0;
    private long testEnd=0;
    private final Runnable ticker=new Runnable(){@Override public void run(){refresh();handler.postDelayed(this,180);}};
    @Override public void onCreate(Bundle b){super.onCreate(b);
        String id=getIntent().getStringExtra("id");config=id==null?new AlarmConfig():AlarmStore.find(this,id);
        if(config==null)config=new AlarmConfig();
        config.walkMeters=getIntent().getIntExtra("walkMeters",config.walkMeters);
        config.strideCm=getIntent().getIntExtra("strideCm",config.strideCm);
        config.shakeTolerance=getIntent().getIntExtra("shakeTolerance",config.shakeTolerance);
        render();
    }
    private void rebuild(){if(tracker!=null)tracker.stop();tracker=new WalkTracker(this,config,()->{});if(WalkTracker.hasPermission(this))tracker.start();}
    @Override protected void onResume(){super.onResume();rebuild();handler.post(ticker);if(tracker!=null&&!tracker.isRunning())askPermission();}
    @Override protected void onPause(){handler.removeCallbacks(ticker);if(tracker!=null)tracker.stop();super.onPause();}
    private void render(){page=Ui.screen(this);
        TextView back=Ui.text(this,"‹    WALK SETTINGS",13,Ui.MUTED,true);back.setOnClickListener(v->finish());Ui.add(page,back);Ui.space(page,this,20);
        Ui.add(page,Ui.label(this,"WAKEY WAKEY    /    SENSOR LAB"));Ui.space(page,this,10);
        Ui.add(page,Ui.text(this,"Make every step count.",33,Ui.WHITE,true));Ui.space(page,this,8);
        Ui.add(page,Ui.text(this,"Walk normally, then try shaking your phone. Tune the values until walking registers and shaking does not.",14,Ui.MUTED,false));Ui.space(page,this,22);
        LinearLayout metric=Ui.card(this);Ui.add(metric,Ui.label(this,"ESTIMATED WALKED DISTANCE"));Ui.space(metric,this,12);
        meterLabel=Ui.text(this,"0.0 / "+config.walkMeters+" m",35,Ui.ORANGE,true);Ui.add(metric,meterLabel);Ui.space(metric,this,12);
        ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.ORANGE));Ui.add(metric,progress);
        stepLabel=Ui.text(this,"0 accepted   ·   0 rejected",13,Ui.WHITE,true);Ui.addMargin(metric,stepLabel,14);
        modeLabel=Ui.text(this,"Preparing sensors…",12,Ui.MUTED,false);Ui.addMargin(metric,modeLabel,10);
        signalLabel=Ui.text(this,"",12,Ui.MUTED,false);Ui.addMargin(metric,signalLabel,8);
        insightLabel=Ui.text(this,"",12,Ui.MUTED,false);Ui.addMargin(metric,insightLabel,7);
        Ui.add(page,metric);Ui.space(page,this,16);
        LinearLayout test=Ui.card(this);Ui.add(test,Ui.label(this,"LIVE VERIFICATION TEST"));Ui.space(test,this,9);
        runLabel=Ui.text(this,"Choose a test below and move with the phone in your pocket or hand.",13,Ui.MUTED,false);Ui.add(test,runLabel);Ui.space(test,this,14);
        TextView walk=Ui.button(this,"▶    TEST WALKING · 15 SEC",true);walk.setOnClickListener(v->begin(1));Ui.add(test,walk);Ui.space(test,this,9);
        TextView shake=Ui.button(this,"TEST SHAKING · 10 SEC",false);shake.setOnClickListener(v->begin(2));Ui.add(test,shake);Ui.space(test,this,11);
        reportLabel=Ui.text(this,"Walking should add distance. Shaking should add none.",13,Ui.MUTED,false);Ui.add(test,reportLabel);
        Ui.add(page,test);Ui.space(page,this,16);
        LinearLayout settings=Ui.card(this);Ui.add(settings,Ui.label(this,"DETECTION SETTINGS"));Ui.space(settings,this,17);
        slider(settings,"TARGET DISTANCE",1,30,config.walkMeters,"m",v->config.walkMeters=v);
        slider(settings,"ESTIMATED STRIDE",35,100,config.strideCm,"cm",v->config.strideCm=v);
        slider(settings,"SHAKE TOLERANCE",1,10,config.shakeTolerance," / 10",v->{config.shakeTolerance=v;mode=0;rebuild();});
        Ui.add(settings,Ui.text(this,"Lower shake tolerance rejects more movement; very low values can also reject real walking. Distance is estimated from detected steps × stride length, not GPS position.",12,Ui.MUTED,false));
        Ui.add(page,settings);Ui.space(page,this,18);
        TextView reset=Ui.button(this,"RESET SENSOR TEST",false);reset.setOnClickListener(v->{mode=0;rebuild();reportLabel.setText("Session reset. Test walking or shaking again.");});Ui.add(page,reset);Ui.space(page,this,11);
        TextView save=Ui.button(this,"SAVE WALK SETTINGS",true);save.setOnClickListener(v->save());Ui.add(page,save);Ui.space(page,this,15);
        Ui.add(page,Ui.text(this,"Important: motion sensors cannot prove physical displacement. Coordinated imitation of walking may still fool the detector; test on your own device. Alarm sounds keep playing during both challenges.",12,Ui.MUTED,false));
        progress.setTag("progress");metric.setTag(progress);
    }
    interface Adjust { void update(int v); }
    private void slider(LinearLayout parent,String title,int min,int max,int value,String unit,Adjust adjust){
        LinearLayout row=Ui.row(this);TextView label=Ui.label(this,title);row.addView(label,new LinearLayout.LayoutParams(0,-2,1));TextView number=Ui.text(this,value+unit,13,Ui.ORANGE,true);row.addView(number);Ui.add(parent,row);
        SeekBar seek=Ui.seek(this,max-min,value-min);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean from){if(!from)return;int v=min+p;adjust.update(v);number.setText(v+unit);}
            public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){} });Ui.add(parent,seek);Ui.space(parent,this,13);
    }
    private void begin(int type){
        if(tracker==null||!tracker.isRunning()){askPermission();return;}
        rebuild();mode=type;startAccepted=tracker.steps();startRejected=tracker.rejected();startShakes=tracker.shakes();testEnd=SystemClock.elapsedRealtime()+(type==1?15000:10000);
        reportLabel.setText(type==1?"Walk naturally. Progress is being measured…":"Shake in place. Valid steps should stay at zero…");
        runLabel.setText(type==1?"WALK TEST IN PROGRESS":"SHAKE TEST IN PROGRESS");
    }
    private void refresh(){if(tracker==null)return;
        meterLabel.setText(String.format(Locale.getDefault(),"%.1f / %d m",tracker.meters(),config.walkMeters));
        stepLabel.setText(tracker.steps()+" accepted   ·   "+tracker.rejected()+" rejected   ·   "+tracker.shakes()+" shake flags");
        modeLabel.setText(tracker.sensorMode()+(tracker.isRunning()?"   ·   LIVE":"   ·   PERMISSION NEEDED"));
        signalLabel.setText(String.format(Locale.getDefault(),"IMPACT  %.2f m/s²     ROTATION  %.2f rad/s",tracker.impact(),tracker.rotation()));
        insightLabel.setText(tracker.reason());
        LinearLayout metric=(LinearLayout)meterLabel.getParent();ProgressBar progress=(ProgressBar)metric.getTag();
        progress.setProgress((int)Math.min(1000,tracker.meters()/config.walkMeters*1000));
        if(mode!=0){long remaining=testEnd-SystemClock.elapsedRealtime();
            if(remaining<=0){int newSteps=tracker.steps()-startAccepted;int rejects=tracker.rejected()-startRejected;
                if(mode==2){reportLabel.setText(newSteps==0?"PASS · Shaking registered no walking steps. Rejected: "+rejects:"WARNING · Shaking produced "+newSteps+" accepted steps. Lower tolerance, then retry.");}
                else reportLabel.setText("WALK RESULT · "+newSteps+" confirmed steps ("+String.format(Locale.getDefault(),"%.1f",newSteps*config.strideCm/100.0)+" m). "+rejects+" rejected.");
                runLabel.setText("TEST COMPLETE");mode=0;
            }else runLabel.setText((mode==1?"WALKING":"SHAKING")+" · "+((remaining+999)/1000)+" SECONDS LEFT");
        }
    }
    private void save(){Intent data=new Intent().putExtra("walkMeters",config.walkMeters).putExtra("strideCm",config.strideCm).putExtra("shakeTolerance",config.shakeTolerance);
        if(getIntent().hasExtra("id")&&!getIntent().getBooleanExtra("editDraft",false)){AlarmStore.put(this,config);Ui.toast(this,"Walk settings saved for this alarm");}
        setResult(RESULT_OK,data);finish();
    }
    private void askPermission(){if(android.os.Build.VERSION.SDK_INT>=29&&!WalkTracker.hasPermission(this))requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION},41);
        else Ui.toast(this,"This phone needs an accelerometer to detect walking.");}
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g);if(req==41&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)rebuild();}
}
