package com.wakeproof.app;

import android.content.*;
import android.os.Build;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){String id=i.getStringExtra("id");if(id==null)return;AlarmConfig a=AlarmStore.find(c,id);if(a==null||!a.enabled)return;
        if(a.days==0){a.enabled=false;AlarmStore.put(c,a);}else{AlarmScheduler.schedule(c,a);}
        Intent start=new Intent(c,AlarmService.class).setAction(AlarmService.START).putExtra("id",id);
        try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(start);else c.startService(start);}catch(Exception ignored){}
    }
}
